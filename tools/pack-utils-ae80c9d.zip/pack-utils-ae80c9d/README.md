Utilities to handle Atmel Device packs
